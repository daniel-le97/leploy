// https://nitro.unjs.io/config
const dev = process.dev
export default defineNitroConfig({
  entry: dev ? './preset/entry.dev.ts' : undefined,
  preset: './preset',
  compressPublicAssets:{
    brotli: true,
    gzip: true
  
  }
})
